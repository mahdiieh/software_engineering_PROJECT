from django.forms import ModelForm
from .models import Critics
from .models import Comments


class CriticsForm(ModelForm):
    class Meta:
        model = Critics
        fields = ['title', 'description']


class CommentsForm(ModelForm):
    class Meta:
        model = Comments
        fields = ['body']
